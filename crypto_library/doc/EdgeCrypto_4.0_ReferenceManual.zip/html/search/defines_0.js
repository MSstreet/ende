var searchData=
[
  ['edge_5fcipher_5fiv_5flength_5fmax_283',['EDGE_CIPHER_IV_LENGTH_MAX',['../edge__crypto_8h.html#ac5c5dc9dd00e83ef4483e4c63667c529',1,'edge_crypto.h']]],
  ['edge_5fcipher_5fkey_5flength_5fmax_284',['EDGE_CIPHER_KEY_LENGTH_MAX',['../edge__crypto_8h.html#abc40a76d62452cef5536f420f71b3d77',1,'edge_crypto.h']]],
  ['edge_5fcipher_5fkey_5flength_5fmin_285',['EDGE_CIPHER_KEY_LENGTH_MIN',['../edge__crypto_8h.html#a21e012d3545665f72ad1053e0fd7ce4b',1,'edge_crypto.h']]]
];
