var indexSectionsWithContent =
{
  0: "_cekmrêëìí",
  1: "_ekr",
  2: "e",
  3: "e",
  4: "m",
  5: "e",
  6: "e",
  7: "e",
  8: "cêëìí",
  9: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "파일들",
  3: "함수",
  4: "변수",
  5: "열거형 타입",
  6: "열거형 멤버",
  7: "매크로",
  8: "그룹들",
  9: "페이지들"
};

