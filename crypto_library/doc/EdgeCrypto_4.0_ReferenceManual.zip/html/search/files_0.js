var searchData=
[
  ['edge_5fcrypto_2eh_158',['edge_crypto.h',['../edge__crypto_8h.html',1,'']]]
];
